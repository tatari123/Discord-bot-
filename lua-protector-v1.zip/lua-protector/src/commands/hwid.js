const { SlashCommandBuilder } = require('discord.js');
const { getUserLicense, resetHwid } = require('../utils/licenseService');
const { stmt } = require('../database/db');
const { successEmbed, errorEmbed, infoEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('hwid')
    .setDescription('Gestion HWID')
    .addSubcommand(sub =>
      sub.setName('reset')
        .setDescription('Réinitialiser ton HWID (consomme 1 reset)')
    ),

  ownerOnly: false,

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'reset') {
      const info = getUserLicense(interaction.user.id);
      if (!info) {
        return interaction.reply({
          embeds: [errorEmbed('Erreur', 'Tu n\'as pas de licence active.')],
          ephemeral: true
        });
      }

      const license = stmt.getLicenseByKey.get(info.key);
      if (!license) {
        return interaction.reply({
          embeds: [errorEmbed('Erreur', 'Licence introuvable.')],
          ephemeral: true
        });
      }

      const result = resetHwid(license.id, interaction.user.id);
      if (!result.success) {
        return interaction.reply({
          embeds: [errorEmbed('Erreur', result.error)],
          ephemeral: true
        });
      }

      await interaction.reply({
        embeds: [successEmbed(
          'HWID réinitialisé',
          `Ton HWID a été réinitialisé.\n**Resets restants :** ${result.resetsLeft}`
        )],
        ephemeral: true
      });
    }
  }
};
