const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('admin')
    .setDescription('Panel d\'administration Lua Protector (Owner uniquement)'),

  ownerOnly: true,

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0xED4245)
      .setTitle('🛡️ LUA PROTECTOR — ADMIN PANEL')
      .setDescription(
        '**Panel réservé au propriétaire.**\n\n' +
        'Gère les licences, la whitelist, la blacklist, les HWID et la protection de scripts.\n\n' +
        '🔴 **Admin Access**'
      )
      .setFooter({ text: `Owner: ${interaction.user.tag}` })
      .setTimestamp();

    const row1 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('admin:create_license')
        .setLabel('Create License')
        .setEmoji('🔑')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('admin:revoke_license')
        .setLabel('Revoke License')
        .setEmoji('🗑️')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('admin:whitelist')
        .setLabel('Whitelist')
        .setEmoji('✅')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('admin:blacklist')
        .setLabel('Blacklist')
        .setEmoji('⛔')
        .setStyle(ButtonStyle.Danger)
    );

    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('admin:manage_hwid')
        .setLabel('Manage HWID')
        .setEmoji('💻')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('admin:protect_script')
        .setLabel('Protect Script')
        .setEmoji('🛡️')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('admin:statistics')
        .setLabel('Statistics')
        .setEmoji('📊')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('admin:logs')
        .setLabel('Logs')
        .setEmoji('📋')
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.reply({
      embeds: [embed],
      components: [row1, row2],
      ephemeral: true
    });
  }
};
